language_identification_system.py :
The input is a file with list of sentences. The code outputs if the sentence is in Bhojpuri (True/False).
To run the code
python language_identification_system.py -i <input file > -d <dictionary>


final_test_sentences.txt :
Test set

test_labels.txt : 
Language label for the correspoding sentence in the test set

bhojpuri_words.txt :
Bhojpuri word dictionary



